﻿# Get Email Thread

> **Agent instruction — read all linked docs before proceeding:** Follow and read every hyperlinked reference document on this page in full before generating XAML. XAML structural patterns (BackupSlots, StoredValue, x:Reference, all-null attributes, namespace declarations) are defined in the linked component, type, and filter docs — not repeated here. If those linked docs also contain hyperlinks to other reference docs, follow those too.

> **Agent instruction — connection:** Before writing XAML, use the available tooling to resolve or search for a connection ID for the connector listed in this doc. If the connection ID cannot be resolved, leave `ConnectionId="{x:Null}"`.

`UiPath.GSuite.Activities.GetEmailThreadConnections`

Retrieves the list of emails in the specified Gmail thread.

**Package:** `UiPath.GSuite.Activities`
**Category:** Gmail
**Connector:** `uipath-google-gmail`

## Properties

### Input

| Name | Display Name | Kind | Type | Required | Default | Description |
|------|-------------|------|------|----------|---------|-------------|
| `ThreadId` | Thread Id | `InArgument` | `string` | Yes | | The unique identifier of the thread. |
| `IncludeAttachmentsMode` | Include attachments | `InArgument` | `IncludeAttachmentsMode` enum: `None`, `OnlyInline`, `All` | `None` | Which attachments (if any) to fetch for each email in the thread. `None` fetches no attachment content; `OnlyInline` fetches only inline attachments (e.g. images embedded in the HTML body); `All` fetches every attachment. |
| `ConnectionId` | Connection ID | `InArgument` | `string` | No | | The Google connection to use. |

### Output

This activity extends `GoogleBaseActivity<List<GmailMessage>>` and returns a `List<`[`GmailMessage`](types/GmailMessage.md)`>` as its `Result` property.

## Output Model

Returns a `List<`[`GmailMessage`](types/GmailMessage.md)`>` containing all messages in the thread.

## Notes

- Prefer using this activity **outside** of [`GSuiteApplicationScope`](GSuiteApplicationScope.md). `*Connections` activities authenticate via Integration Service independently — no scope wrapper required. Place inside the scope only when Integration Service is unavailable or when using API Key, OAuth Client ID, or Service Account credentials directly via the scope.
- The `ThreadId` property is required.
- `IncludeAttachmentsMode` defaults to `None` — no attachment content is fetched unless set to `OnlyInline` or `All`.
